//Author: Shawn Wilkinson

#include "stdafx.h"
#include <iostream>

using namespace std;

int main()
{
    //Print Stars
    cout << "   *   " << endl;
    cout << "  ***  " << endl;
    cout << " ***** " << endl;
    cout << "*******" << endl;
    cout << " ***** " << endl;
    cout << "  ***  " << endl;
    cout << "   *   " << endl;

    //Exit Program
    system("PAUSE");
    return 0;
}